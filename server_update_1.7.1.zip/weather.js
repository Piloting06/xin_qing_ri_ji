const express = require('express');
const auth = require('../middleware/auth');
const router = express.Router();

const QWEATHER_KEY = 'bb1c6fe8d62c40e28e8e25b31fa5f1ca';
const QWEATHER_BASE = 'https://devapi.qweather.com/v7/weather';
const QWEATHER_GEO = 'https://geoapi.qweather.com/v2/city';
const CACHE_TTL = 10 * 60 * 1000;

const cache = new Map();

function getCached(key) {
  const entry = cache.get(key);
  if (entry && Date.now() - entry.time < CACHE_TTL) return entry.data;
  cache.delete(key);
  return null;
}
function setCache(key, data) {
  cache.set(key, { data, time: Date.now() });
}

function mapQWeather(now) {
  const icon = String(now.icon || '');
  const text = now.text || '';
  if (icon === '100' || icon === '150') return { weather: '晴', code: 0 };
  if (icon === '101' || icon === '151') return { weather: '多云', code: 1 };
  if (icon === '102' || icon === '152') return { weather: '少云', code: 1 };
  if (icon === '103' || icon === '153') return { weather: '晴间多云', code: 2 };
  if (icon === '104') return { weather: '阴', code: 3 };
  if (['300','301'].includes(icon)) return { weather: '阵雨', code: 61 };
  if (icon === '302') return { weather: '雷阵雨', code: 95 };
  if (icon === '303') return { weather: '强雷阵雨', code: 96 };
  if (icon === '304') return { weather: '雷阵雨伴有冰雹', code: 96 };
  if (icon === '305') return { weather: '小雨', code: 61 };
  if (icon === '306') return { weather: '中雨', code: 63 };
  if (icon === '307') return { weather: '大雨', code: 65 };
  if (['308','309'].includes(icon)) return { weather: '暴雨', code: 65 };
  if (['310','311','312'].includes(icon)) return { weather: '大暴雨', code: 65 };
  if (icon === '313') return { weather: '特大暴雨', code: 65 };
  if (icon === '314') return { weather: '小毛毛雨', code: 51 };
  if (icon === '315') return { weather: '中毛毛雨', code: 53 };
  if (icon === '316') return { weather: '毛毛雨', code: 53 };
  if (icon === '317') return { weather: '强毛毛雨', code: 55 };
  if (icon === '399') return { weather: '雨', code: 61 };
  if (['400','408'].includes(icon)) return { weather: '小雪', code: 71 };
  if (['401','409'].includes(icon)) return { weather: '中雪', code: 73 };
  if (['402','410'].includes(icon)) return { weather: '大雪', code: 75 };
  if (icon === '403') return { weather: '暴雪', code: 75 };
  if (['404','405','406','407'].includes(icon)) return { weather: '雨夹雪', code: 85 };
  if (icon === '499') return { weather: '雪', code: 71 };
  if (icon === '500') return { weather: '雾', code: 45 };
  if (icon === '501') return { weather: '雾霾', code: 45 };
  if (icon === '502') return { weather: '霾', code: 45 };
  if (icon === '503') return { weather: '扬沙', code: 45 };
  if (icon === '508') return { weather: '沙尘暴', code: 45 };
  return { weather: text || '晴', code: 0 };
}

async function fetchQWeather(url) {
  const https = require('https');
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(e); }
      });
    }).on('error', reject);
  });
}

router.get('/', auth, async (req, res) => {
  try {
    let lat = parseFloat(req.query.lat);
    let lon = parseFloat(req.query.lon);
    if (isNaN(lat) || isNaN(lon)) return res.status(400).json({ message: '缺少经纬度参数' });

    const locKey = `${lat.toFixed(2)},${lon.toFixed(2)}`;
    const cached = getCached(locKey);
    if (cached) return res.json(cached);

    const locStr = `${lon.toFixed(2)},${lat.toFixed(2)}`;

    const nowData = await fetchQWeather(`${QWEATHER_BASE}/now?location=${locStr}&key=${QWEATHER_KEY}`);
    if (nowData.code !== '200' || !nowData.now) return res.status(502).json({ message: '获取天气失败' });

    const dayData = await fetchQWeather(`${QWEATHER_BASE}/3d?location=${locStr}&key=${QWEATHER_KEY}`);
    const daily = (dayData.code === '200' && dayData.daily) ? dayData.daily : [];

    const now = nowData.now;
    const mapped = mapQWeather(now);

    const result = {
      current: {
        weather: mapped.weather,
        weather_code: mapped.code,
        temp_current: Math.round(parseFloat(now.temp) || 0),
        feels_like: Math.round(parseFloat(now.feelsLike) || parseFloat(now.temp) || 0),
        humidity: parseInt(now.humidity) || null,
        wind_current: parseFloat(now.windSpeed) || null,
        observed_at: nowData.updateTime ? nowData.updateTime.replace('+08:00', '') : null,
      },
      today: daily.length > 0 ? formatDay(daily[0]) : {},
      tomorrow: daily.length > 1 ? formatDay(daily[1]) : {},
      day_after: daily.length > 2 ? formatDay(daily[2]) : {},
    };

    setCache(locKey, result);
    res.json(result);
  } catch (e) { res.status(502).json({ message: '获取天气失败' }); }
});

function formatDay(day) {
  const mapped = mapQWeather({ icon: day.iconDay, text: day.textDay });
  return {
    weather: mapped.weather,
    weather_code: mapped.code,
    temp_max: Math.round(parseFloat(day.tempMax) || 0),
    temp_min: Math.round(parseFloat(day.tempMin) || 0),
    sunrise: day.sunrise || null,
    sunset: day.sunset || null,
    moonrise: day.moonrise || null,
    moonset: day.moonset || null,
    precip_prob: parseInt(day.precip) || null,
    humidity: parseInt(day.humidity) || null,
    wind_speed: parseFloat(day.windSpeedDay) || null,
  };
}

router.get('/reverse', async (req, res) => {
  try {
    const lat = parseFloat(req.query.lat), lon = parseFloat(req.query.lon);
    if (isNaN(lat) || isNaN(lon)) return res.status(400).json({ message: '缺少经纬度' });
    const data = await fetchQWeather(`${QWEATHER_GEO}/lookup?location=${lon.toFixed(2)},${lat.toFixed(2)}&key=${QWEATHER_KEY}`);
    if (data.code === '200' && data.location && data.location.length > 0) {
      const loc = data.location[0];
      return res.json({ city: loc.name, region: loc.adm1, country: loc.country });
    }
    res.json({ city: '未知', region: '', country: '' });
  } catch (e) { res.status(502).json({ message: '查询失败' }); }
});

router.get('/search', async (req, res) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).json({ message: '请输入城市名' });
    const data = await fetchQWeather(`${QWEATHER_GEO}/lookup?location=${encodeURIComponent(q)}&key=${QWEATHER_KEY}`);
    if (data.code === '200' && data.location) {
      return res.json({ cities: data.location.map(loc => ({ name: loc.name, latitude: parseFloat(loc.lat), longitude: parseFloat(loc.lon), admin1: loc.adm1, country: loc.country })) });
    }
    res.json({ cities: [] });
  } catch (e) { res.status(502).json({ message: '搜索失败' }); }
});

router.get('/location', async (req, res) => {
  try {
    const https = require('https');
    https.get('http://ip-api.com/json/?fields=status,lat,lon,city,regionName,country', (resp) => {
      let d = ''; resp.on('data', c => d += c); resp.on('end', () => {
        try {
          const j = JSON.parse(d);
          if (j.status === 'success') res.json({ lat: j.lat, lon: j.lon, city: j.city, region: j.regionName, country: j.country });
          else res.json({ lat: null, lon: null, city: '未知' });
        } catch (_) { res.json({ lat: null, lon: null, city: '未知' }); }
      });
    }).on('error', () => res.json({ lat: null, lon: null, city: '未知' }));
  } catch (_) { res.json({ lat: null, lon: null, city: '未知' }); }
});

module.exports = router;
